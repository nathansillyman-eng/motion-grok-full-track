#!/usr/bin/env node
"use strict";
const { readFileSync } = require("node:fs");
const assert = require("node:assert/strict");

function load(p) {
  (0, eval)(readFileSync(p, "utf8"));
}
load("/workspace/motion/v9-inline.js");
load("/workspace/motion/hooks.js");

const M = globalThis.MOTION;
const P = globalThis.MOTION_PAYLOAD;
const fails = [];
function ok(name, cond) {
  if (!cond) fails.push(name);
}

ok("version r3", M.version === "v9-full-r3");
ok("not wear", P.wearReady === false && P.status === "NOT_WEAR_READY");
ok("4k false", P.fourKValidated === false);
ok("lead off", P.leadApplied === false && M.leadMs === null);
ok("no 0.85 in transform", !JSON.stringify(P.transformContract).includes("0.85"));
ok("windows unlabeled", P.windows[0].verdict === undefined && P.windows[0].labelStatus === "UNREPRODUCIBLE_NOT_PHYSICAL_TRUTH");
ok("class unreproducible", P.classification.reproducedByDeclaredRule === false);
ok("LK yaw 258 frozen", P.yawRate[258] === 0.3486);
ok("LK meas 258 frozen", P.measuredLeanDeg[258] === 1.2919);

// 1. selfTest must not promote
ok("boot unverified", M.sourceIdentity.verified === false);
const pre = M.sample(258);
ok("boot sample closed", pre.status === "FAIL_CLOSED" && pre.appliedCorrectionDeg === 0);
const st = M.selfTest();
ok("selfTest ok " + JSON.stringify(st.fails), st.ok);
ok("selfTest did not mutate", st.mutatedProduction === false && st.productionVerifiedAfter === false);
const post = M.sample(258);
ok("after selfTest still closed", post.status === "FAIL_CLOSED" && M.sourceIdentity.verified === false);

// 2. real verify then sample
M.setSourceIdentity({ sha256: P.sourceVideoSha256, frameCount: 1514, fps: 24, durationSec: 63.083333 });
ok("verified", M.sourceIdentity.verified === true);
M.setDial(1);
const f258 = M.setDecodedFrame(258);
ok("258 ok", f258.status === "OK");
ok("258 same-frame target", Math.abs(f258.targetLeanDeg - 40.459) < 0.01);
ok("258 not 83", Math.abs(f258.appliedCorrectionDeg - 39.1671) < 0.02);

// 3. stale RVFC / ended
function fakeVideo(extra) {
  const v = {
    ended: false,
    seeking: false,
    currentTime: 10.875,
    duration: 63.083333,
    currentSrc: "ride.mp4",
    src: "ride.mp4",
    listeners: {},
    addEventListener(type, fn) {
      (this.listeners[type] || (this.listeners[type] = [])).push(fn);
    },
    removeEventListener(type, fn) {
      this.listeners[type] = (this.listeners[type] || []).filter((x) => x !== fn);
    },
    fire(type) {
      (this.listeners[type] || []).forEach((fn) => fn());
    },
    requestVideoFrameCallback(fn) {
      this._rvfc = fn;
      return 1;
    },
    cancelVideoFrameCallback() {
      this._rvfc = null;
    },
  };
  Object.assign(v, extra || {});
  return v;
}
const vid = fakeVideo();
M.attachVideo(vid);
vid._rvfc(0, { mediaTime: 261 / 24 });
ok("rvfc 261 applied", M.cockpit.status === "OK" && M.cockpit.appliedCorrectionDeg !== 0);
vid.ended = true;
vid.fire("ended");
ok("ended neutralizes", M.cockpit.appliedCorrectionDeg === 0 && M.cockpit.status === "FAIL_CLOSED");
const tickAfterEnd = M.applyTransforms({ decodedFrame: 261, correctionOffset: { rotation: { z: 9 } }, vehicleRoot: { rotation: { z: 0 } }, bikeVisual: { rotation: { z: 0 } } });
ok("ended tick does not restore 261", tickAfterEnd.status === "FAIL_CLOSED" && tickAfterEnd.correctionOffsetRad === 0);

vid.ended = false;
vid.seeking = true;
vid.fire("seeking");
ok("seeking 0", M.cockpit.appliedCorrectionDeg === 0);
vid.seeking = false;
vid.fire("seeked");
ok("seeked waits", M.cockpit.appliedCorrectionDeg === 0);
const staleTick = M.fromVideoElement(vid);
ok("stale without rvfc 0", staleTick.appliedCorrectionDeg === 0);

vid.currentSrc = "other.mp4";
vid.fire("loadstart");
ok("src change revokes", M.sourceIdentity.verified === false);
M.setSourceIdentity({ sha256: P.sourceVideoSha256, frameCount: 1514, fps: 24, durationSec: 63.083333 });

M.detachVideo();
ok("detach cancels", vid._rvfc === null);

// 4. numeric validation of unused slots
function cloneP() {
  return JSON.parse(JSON.stringify(P));
}
function rejectCase(name, mutate) {
  const q = cloneP();
  mutate(q);
  const m = payloadReject(q);
  ok(name, m);
}
function payloadReject(q) {
  const saved = globalThis.MOTION_PAYLOAD;
  globalThis.MOTION_PAYLOAD = q;
  const api = globalThis.MOTION;
  const before = api.sourceIdentity.verified;
  api.attachPayload(q);
  const bad = api.cockpit.status === "FAIL_CLOSED" && /payload invalid/.test(api.cockpit.reason || "");
  api.attachPayload(saved);
  globalThis.MOTION_PAYLOAD = saved;
  if (before) api.setSourceIdentity({ sha256: P.sourceVideoSha256, frameCount: 1514, fps: 24, durationSec: 63.083333 });
  return bad;
}
rejectCase("string deficitRoll", (q) => {
  q.deficitRollDeg[10] = "nope";
});
rejectCase("boolean measured", (q) => {
  q.measuredLeanDeg[20] = true;
});
rejectCase("wrong decodedFrame", (q) => {
  q.decodedFrame[5] = 9;
});
rejectCase("NaN target", (q) => {
  q.targetLeanDeg[100] = NaN;
});
rejectCase("Inf yaw", (q) => {
  q.yawRate[40] = Infinity;
});
rejectCase("short array", (q) => {
  q.heading = q.heading.slice(0, 10);
});
rejectCase("non-monotonic ts", (q) => {
  q.videoTimestamp[10] = q.videoTimestamp[9];
});
rejectCase("bad correctionValid", (q) => {
  q.correctionValid[3] = "yes";
});

M.setSourceIdentity({ sha256: P.sourceVideoSha256, frameCount: 1514, fps: 24, durationSec: 63.083333 });
M.setDial(1);
M.setDecodedFrame(258);

// 5. dial survives ticks
M.setDial(0.2);
ok("dial 0.2", M.getDial() === 0.2);
for (let i = 0; i < 8; i++) {
  M.applyTransforms({
    decodedFrame: 258,
    correctionOffset: { rotation: { z: 0 } },
    vehicleRoot: { rotation: { z: 0 } },
    bikeVisual: { rotation: { z: 0 } },
  });
}
ok("dial 0.2 survives ticks", M.getDial() === 0.2);
M.setDial(0.9);
for (let i = 0; i < 5; i++) M.setDecodedFrame(258);
ok("dial 0.9 survives frames", M.getDial() === 0.9);
ok("0.9 applied scaled", Math.abs(M.cockpit.appliedCorrectionDeg - 0.9 * 39.1671) < 0.05);

// 6. transforms
M.setDial(1);
const offset = { rotation: { z: 0 }, parent: null };
const bike = { rotation: { z: 0 }, parent: null };
const root = { rotation: { z: 0 }, parent: null };
const tracked = { rotation: { z: 0.25 }, parent: null };
const tr = M.applyTransforms({
  decodedFrame: 258,
  vehicleRoot: root,
  bikeVisual: bike,
  correctionOffset: offset,
  trackedCamera: tracked,
});
ok("offset written", Math.abs(offset.rotation.z - (39.1671 * Math.PI) / 180) < 1e-4);
ok("tracked untouched", tracked.rotation.z === 0.25);
ok("root 0", root.rotation.z === 0);
ok("chase 0 field", tr.chaseCamRad === 0);

const nestedCam = { rotation: { z: 0.25 }, parent: bike };
bike.parent = root;
const forbidden = M.applyTransforms({
  decodedFrame: 258,
  vehicleRoot: root,
  bikeVisual: bike,
  correctionOffset: nestedCam,
  trackedCamera: nestedCam,
});
ok("hierarchy rejected", forbidden.hierarchyForbidden === true && forbidden.correctionOffsetRad === 0);

const oob = M.sample(1514);
ok("1514 0", oob.appliedCorrectionDeg === 0);
ok("neg 0", M.sample(-1).appliedCorrectionDeg === 0);
M.setVehicle("plant");
ok("plant 0", M.sample(258).appliedCorrectionDeg === 0);
M.setVehicle("striker");
M.setView("chase");
ok("chase 0", M.sample(258).appliedCorrectionDeg === 0);
M.setView("cockpit");

ok("wrong sha closed", (() => {
  M.setSourceIdentity({ sha256: "deadbeef", frameCount: 1514, fps: 24, durationSec: 63.083333 });
  const r = M.sample(258);
  M.setSourceIdentity({ sha256: P.sourceVideoSha256, frameCount: 1514, fps: 24, durationSec: 63.083333 });
  return r.appliedCorrectionDeg === 0;
})());

if (fails.length) {
  console.error("FAIL", fails);
  process.exit(1);
}
console.log(
  JSON.stringify(
    {
      ok: true,
      version: M.version,
      wearReady: false,
      fourKValidated: false,
      selfTest: st,
      f258: { target: f258.targetLeanDeg, applied: f258.appliedCorrectionDeg },
    },
    null,
    2,
  ),
);
