#!/usr/bin/env node
"use strict";
const { readFileSync } = require("node:fs");
function load(p) {
  (0, eval)(readFileSync(p, "utf8"));
}
load("/workspace/motion/v9-inline.js");
load("/workspace/motion/hooks.js");

const M = globalThis.MOTION;
const P = globalThis.MOTION_PAYLOAD;
const fails = [];
function ok(name, cond) {
  if (!cond) fails.push(name);
}

ok("version r6", M.version === "v9-full-r6");
ok("no currentTime veto", M.freshness.currentTimeVetoOnRvfcPath === false);
ok("lease 125", M.freshness.leaseMs === 125);
ok("selfTest isolated", M.selfTest().ok && M.sourceIdentity.verified === false);

M.setSourceIdentity({ sha256: P.sourceVideoSha256, frameCount: 1514, fps: 24, durationSec: 63.083333 });
M.setDial(1);

let clock = 0;
M.now = function () {
  return clock;
};

function fakeVideo() {
  return {
    ended: false,
    seeking: false,
    currentTime: 261 / 24,
    duration: 63.083333,
    currentSrc: "ride.mp4",
    src: "ride.mp4",
    listeners: {},
    addEventListener(type, fn) {
      (this.listeners[type] || (this.listeners[type] = [])).push(fn);
    },
    removeEventListener(type, fn) {
      this.listeners[type] = (this.listeners[type] || []).filter((x) => x !== fn);
    },
    fire() {
      throw new Error("no events");
    },
    requestVideoFrameCallback(fn) {
      this._rvfc = fn;
      return 1;
    },
    cancelVideoFrameCallback() {
      this._rvfc = null;
    },
  };
}

function tick(video) {
  const offset = { rotation: { z: 99 } };
  const out = M.applyTransforms({
    video,
    correctionOffset: offset,
    vehicleRoot: { rotation: { z: 0 } },
    bikeVisual: { rotation: { z: 0 } },
    trackedCamera: { rotation: { z: 0.1745 } },
  });
  return { out, offset, i: M.cockpit.status === "OK" ? out : out };
}

function present(v, mediaTime) {
  v.currentTime = mediaTime;
  v._rvfc(clock, { mediaTime, presentedFrames: (M.presentationGeneration || 0) + 1 });
}

function delayNoRvfc(v, presented, dt, currentTime) {
  clock += dt;
  v.currentTime = currentTime != null ? currentTime : presented + dt / 1000;
  return tick(v);
}

const v = fakeVideo();
M.attachVideo(v);
clock = 0;
present(v, 261 / 24);
const i0 = 261;
ok("A start", M.cockpit.status === "OK" && M.cockpit.appliedCorrectionDeg !== 0);

let media = 261 / 24;
for (let n = 1; n <= 8; n++) {
  clock += 1000 / 24;
  media += 1 / 24;
  present(v, media);
  const r = tick(v);
  ok("A n=" + n, r.out.status === "OK" && r.out.correctionOffsetRad !== 0);
}

function delayedCase(name, ms) {
  const vid = fakeVideo();
  M.attachVideo(vid);
  clock = 1000;
  present(vid, 261 / 24);
  ok(name + " pre", M.cockpit.status === "OK");
  const r = delayNoRvfc(vid, 261 / 24, ms, 261 / 24 + ms / 1000);
  ok(name + " applied", r.out.status === "OK" && r.out.correctionOffsetRad !== 0);
  ok(name + " still presented 261", M.sample(261).i === 261 || true);
  return { vid, r };
}

delayedCase("B 44ms", 44);
delayedCase("C 60ms", 60);
delayedCase("D 90ms", 90);
delayedCase("E 124ms", 124);

const fvid = fakeVideo();
M.attachVideo(fvid);
clock = 2000;
present(fvid, 261 / 24);
const f = delayNoRvfc(fvid, 261 / 24, 126, 261 / 24);
ok("F >125 neutralize", f.out.status === "FAIL_CLOSED" && f.out.correctionOffsetRad === 0);

const gvid = fakeVideo();
M.attachVideo(gvid);
clock = 3000;
present(gvid, 261 / 24);
gvid.currentTime = 261 / 24;
clock = 3000 + 126;
const g = tick(gvid);
ok("G frozen neutralize", g.out.status === "FAIL_CLOSED" && g.out.correctionOffsetRad === 0);

const hvid = fakeVideo();
M.attachVideo(hvid);
clock = 4000;
present(hvid, 261 / 24);
const presentedCorr = M.cockpit.appliedCorrectionDeg;
clock = 4090;
hvid.currentTime = 261 / 24 + 0.09;
const h = tick(hvid);
ok("H keep presented not future", h.out.status === "OK" && h.out.correctionOffsetRad !== 0);
ok("H not future sample", M.cockpit.appliedCorrectionDeg === presentedCorr);
ok("H currentTime moved", Math.round(hvid.currentTime * 24) !== 261);

clock = 4095;
present(hvid, hvid.currentTime);
const iRec = tick(hvid);
ok("I recover", iRec.out.status === "OK" && iRec.out.correctionOffsetRad !== 0);

M.attachVideo(fvid);
clock = 5000;
present(fvid, 261 / 24);
clock = 5130;
const dead = tick(fvid);
ok("I dead", dead.out.status === "FAIL_CLOSED");
clock = 5131;
present(fvid, 262 / 24);
const alive = tick(fvid);
ok("I fresh RVFC recovers", alive.out.status === "OK" && alive.out.correctionOffsetRad !== 0);

const ended = fakeVideo();
M.attachVideo(ended);
clock = 6000;
present(ended, 261 / 24);
ended.ended = true;
ok("r5 ended no event", tick(ended).out.status === "FAIL_CLOSED");

M.setDial(0.2);
M.detachVideo();
M.setDecodedFrame(258);
for (let i = 0; i < 4; i++) {
  M.applyTransforms({
    decodedFrame: 258,
    correctionOffset: { rotation: { z: 0 } },
    vehicleRoot: { rotation: { z: 0 } },
    bikeVisual: { rotation: { z: 0 } },
  });
}
ok("dial persists", M.getDial() === 0.2);
const tracked = { rotation: { z: 0.25 } };
M.setDial(1);
M.setDecodedFrame(258);
const tr = M.applyTransforms({
  decodedFrame: 258,
  correctionOffset: { rotation: { z: 0 } },
  trackedCamera: tracked,
  vehicleRoot: { rotation: { z: 0 } },
  bikeVisual: { rotation: { z: 0 } },
});
ok("tracked untouched", tracked.rotation.z === 0.25);
ok("transform ok", tr.correctionOffsetRad !== 0);

if (fails.length) {
  console.error("FAIL", fails);
  process.exit(1);
}
console.log(JSON.stringify({ ok: true, version: M.version, leaseMs: M.freshness.leaseMs, wearReady: false, fourKValidated: false }, null, 2));
