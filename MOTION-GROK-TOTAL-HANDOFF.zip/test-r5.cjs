#!/usr/bin/env node
"use strict";
const { readFileSync } = require("node:fs");
function load(p) {
  (0, eval)(readFileSync(p, "utf8"));
}
load("/workspace/motion/v9-inline.js");
load("/workspace/motion/hooks.js");

const M = globalThis.MOTION;
const P = globalThis.MOTION_PAYLOAD;
const fails = [];
function ok(name, cond) {
  if (!cond) fails.push(name);
}

ok("version r5", M.version === "v9-full-r5");
ok("lease 125", M.freshness.leaseMs === 125);
ok("boot unverified", M.sourceIdentity.verified === false);
ok("selfTest isolated", M.selfTest().ok && M.sourceIdentity.verified === false);

M.setSourceIdentity({ sha256: P.sourceVideoSha256, frameCount: 1514, fps: 24, durationSec: 63.083333 });
M.setDial(1);

let clock = 0;
M.now = function () {
  return clock;
};

function fakeVideo(extra) {
  const v = {
    ended: false,
    seeking: false,
    currentTime: 261 / 24,
    duration: 63.083333,
    currentSrc: "ride.mp4",
    src: "ride.mp4",
    listeners: {},
    addEventListener(type, fn) {
      (this.listeners[type] || (this.listeners[type] = [])).push(fn);
    },
    removeEventListener(type, fn) {
      this.listeners[type] = (this.listeners[type] || []).filter((x) => x !== fn);
    },
    fire() {
      throw new Error("do not fire events in this control");
    },
    requestVideoFrameCallback(fn) {
      this._rvfc = fn;
      return 1;
    },
    cancelVideoFrameCallback() {
      this._rvfc = null;
    },
  };
  Object.assign(v, extra || {});
  return v;
}

function tick(video) {
  const offset = { rotation: { z: 99 } };
  const out = M.applyTransforms({
    video,
    correctionOffset: offset,
    vehicleRoot: { rotation: { z: 0 } },
    bikeVisual: { rotation: { z: 0 } },
    trackedCamera: { rotation: { z: 0.1745 } },
  });
  return { out, offset };
}

function present(v, mediaTime) {
  v.currentTime = mediaTime;
  if (typeof v._rvfc === "function") v._rvfc(clock, { mediaTime, presentedFrames: M.presentationGeneration + 1 });
}

const vid = fakeVideo();
M.attachVideo(vid);
clock = 0;
present(vid, 261 / 24);
ok("nonzero start", M.cockpit.status === "OK" && M.cockpit.appliedCorrectionDeg !== 0);
ok("gen 1", M.presentationGeneration === 1);

for (const t of [0, 16, 32, 48, 80, 100, 124]) {
  clock = t;
  const r = tick(vid);
  ok("pre-lease t=" + t, r.out.status === "OK" && r.out.correctionOffsetRad !== 0);
}

clock = 126;
const expired = tick(vid);
ok("post-lease 0", expired.out.status === "FAIL_CLOSED" && expired.out.correctionOffsetRad === 0);
ok("post-lease applied 0", M.cockpit.appliedCorrectionDeg === 0);
ok("no event used", vid.ended === false && vid.seeking === false);

M.setSourceIdentity({ sha256: P.sourceVideoSha256, frameCount: 1514, fps: 24, durationSec: 63.083333 });
const play = fakeVideo();
M.attachVideo(play);
clock = 0;
let media = 261 / 24;
present(play, media);
ok("play start", M.cockpit.appliedCorrectionDeg !== 0);
for (let n = 1; n <= 12; n++) {
  const jitter = n % 2 === 0 ? 8 : -6;
  clock += 1000 / 24 + jitter;
  media += 1 / 24;
  present(play, media);
  const r = tick(play);
  ok("play n=" + n, r.out.status === "OK" && r.out.correctionOffsetRad !== 0);
}

clock += 90;
const delayed = tick(play);
ok("delayed frame still live", delayed.out.status === "OK" && delayed.out.correctionOffsetRad !== 0);
clock += 5;
media += 1 / 24;
present(play, media);
const recovered = tick(play);
ok("recovered after hiccup", recovered.out.status === "OK" && recovered.out.correctionOffsetRad !== 0);

const ended = fakeVideo();
M.attachVideo(ended);
clock += 1;
present(ended, 261 / 24);
ok("r4 pre ended", M.cockpit.appliedCorrectionDeg !== 0);
ended.ended = true;
const e = tick(ended);
ok("r4 ended no event", e.out.status === "FAIL_CLOSED" && e.out.correctionOffsetRad === 0);

M.setDial(0.2);
M.detachVideo();
M.setDecodedFrame(258);
for (let i = 0; i < 5; i++) {
  M.applyTransforms({
    decodedFrame: 258,
    correctionOffset: { rotation: { z: 0 } },
    vehicleRoot: { rotation: { z: 0 } },
    bikeVisual: { rotation: { z: 0 } },
  });
}
ok("dial persists", M.getDial() === 0.2);

const tracked = { rotation: { z: 0.25 }, parent: null };
M.setDial(1);
M.setDecodedFrame(258);
const tr = M.applyTransforms({
  decodedFrame: 258,
  correctionOffset: { rotation: { z: 0 } },
  trackedCamera: tracked,
  vehicleRoot: { rotation: { z: 0 } },
  bikeVisual: { rotation: { z: 0 } },
});
ok("tracked untouched", tracked.rotation.z === 0.25);
ok("transform sibling", tr.hierarchyForbidden === false && tr.correctionOffsetRad !== 0);

if (fails.length) {
  console.error("FAIL", fails);
  process.exit(1);
}
console.log(
  JSON.stringify(
    {
      ok: true,
      version: M.version,
      leaseMs: M.freshness.leaseMs,
      wearReady: false,
      fourKValidated: false,
    },
    null,
    2,
  ),
);
