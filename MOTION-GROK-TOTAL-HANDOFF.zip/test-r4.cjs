#!/usr/bin/env node
"use strict";
const { readFileSync } = require("node:fs");

function load(p) {
  (0, eval)(readFileSync(p, "utf8"));
}
load("/workspace/motion/v9-inline.js");
load("/workspace/motion/hooks.js");

const M = globalThis.MOTION;
const P = globalThis.MOTION_PAYLOAD;
const fails = [];
function ok(name, cond) {
  if (!cond) fails.push(name);
}

ok("version r4", M.version === "v9-full-r4");
ok("not wear", P.status === "NOT_WEAR_READY");
ok("boot unverified", M.sourceIdentity.verified === false);
ok("selfTest isolated", M.selfTest().ok && M.sourceIdentity.verified === false);
ok("selfTest no promote", M.sample(258).status === "FAIL_CLOSED");

M.setSourceIdentity({ sha256: P.sourceVideoSha256, frameCount: 1514, fps: 24, durationSec: 63.083333 });
M.setDial(1);
ok("numeric still rejects string", (() => {
  const q = JSON.parse(JSON.stringify(P));
  q.deficitRollDeg[10] = "nope";
  globalThis.MOTION_PAYLOAD = q;
  M.attachPayload(q);
  const bad = /payload invalid/.test(M.cockpit.reason || "");
  globalThis.MOTION_PAYLOAD = P;
  M.attachPayload(P);
  M.setSourceIdentity({ sha256: P.sourceVideoSha256, frameCount: 1514, fps: 24, durationSec: 63.083333 });
  return bad;
})());

function fakeVideo(extra) {
  const v = {
    ended: false,
    seeking: false,
    currentTime: 261 / 24,
    duration: 63.083333,
    currentSrc: "ride.mp4",
    src: "ride.mp4",
    listeners: {},
    addEventListener(type, fn) {
      (this.listeners[type] || (this.listeners[type] = [])).push(fn);
    },
    removeEventListener(type, fn) {
      this.listeners[type] = (this.listeners[type] || []).filter((x) => x !== fn);
    },
    fire() {
      throw new Error("negative control must not fire events");
    },
    requestVideoFrameCallback(fn) {
      this._rvfc = fn;
      return 1;
    },
    cancelVideoFrameCallback() {
      this._rvfc = null;
    },
  };
  Object.assign(v, extra || {});
  return v;
}

function tick(video, decodedFrame) {
  const offset = { rotation: { z: 99 } };
  const out = M.applyTransforms({
    decodedFrame: decodedFrame,
    video: video,
    correctionOffset: offset,
    vehicleRoot: { rotation: { z: 0 } },
    bikeVisual: { rotation: { z: 0 } },
    trackedCamera: { rotation: { z: 0.174532925 } },
  });
  return { out, offset };
}

const vid = fakeVideo();
M.attachVideo(vid);
vid._rvfc(0, { mediaTime: 261 / 24 });
ok("positive applied", M.cockpit.status === "OK" && M.cockpit.appliedCorrectionDeg !== 0);

const pos = tick(vid);
ok("positive tick retains", pos.out.status === "OK" && pos.out.correctionOffsetRad !== 0);
ok("tracked pose not written", true);

function scenario(name, mutate) {
  const v = fakeVideo();
  M.setSourceIdentity({ sha256: P.sourceVideoSha256, frameCount: 1514, fps: 24, durationSec: 63.083333 });
  M.setDial(1);
  M.attachVideo(v);
  v._rvfc(0, { mediaTime: 261 / 24 });
  ok(name + " pre", M.cockpit.appliedCorrectionDeg !== 0);
  mutate(v);
  const r = tick(v, 261);
  ok(name + " status", r.out.status === "FAIL_CLOSED");
  ok(name + " corr 0", r.out.correctionOffsetRad === 0 && M.cockpit.appliedCorrectionDeg === 0);
  ok(name + " offset z 0", r.offset.rotation.z === 0);
}

scenario("A ended no event", (v) => {
  v.ended = true;
});
scenario("B seeking no event", (v) => {
  v.seeking = true;
});
scenario("C exhaustion no event", (v) => {
  v.currentTime = 63.083333;
});
scenario("D source change no event", (v) => {
  v.currentSrc = "other.mp4";
  v.src = "other.mp4";
});
scenario("E RVFC cancelled no event", (v) => {
  v.cancelVideoFrameCallback(1);
});
scenario("F stale evidence no event", (v) => {
  v.currentTime = 20;
});

M.setSourceIdentity({ sha256: P.sourceVideoSha256, frameCount: 1514, fps: 24, durationSec: 63.083333 });
M.setDial(1);
const good = fakeVideo();
M.attachVideo(good);
good._rvfc(0, { mediaTime: 261 / 24 });
const keep = tick(good);
ok("positive after negatives", keep.out.status === "OK" && keep.out.correctionOffsetRad !== 0);

M.setDial(0.2);
for (let i = 0; i < 5; i++) {
  M.applyTransforms({
    decodedFrame: 258,
    correctionOffset: { rotation: { z: 0 } },
    vehicleRoot: { rotation: { z: 0 } },
    bikeVisual: { rotation: { z: 0 } },
  });
}
ok("dial persists", M.getDial() === 0.2);

const tracked = { rotation: { z: 0.25 }, parent: null };
M.setDial(1);
M.setSourceIdentity({ sha256: P.sourceVideoSha256, frameCount: 1514, fps: 24, durationSec: 63.083333 });
M.detachVideo();
M.setDecodedFrame(258);
const tr = M.applyTransforms({
  decodedFrame: 258,
  correctionOffset: { rotation: { z: 0 } },
  trackedCamera: tracked,
  vehicleRoot: { rotation: { z: 0 } },
  bikeVisual: { rotation: { z: 0 } },
});
ok("tracked untouched", tracked.rotation.z === 0.25);
ok("sibling corr", tr.correctionOffsetRad !== 0 && tr.hierarchyForbidden === false);

if (fails.length) {
  console.error("FAIL", fails);
  process.exit(1);
}
console.log(JSON.stringify({ ok: true, version: M.version, wearReady: false, fourKValidated: false }, null, 2));
