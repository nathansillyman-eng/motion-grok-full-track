#!/usr/bin/env python3
"""LEAN GATE v9-full — source-bound 1514-frame measurement of ride.mp4.

Instrument (Claude 2026-09-07):
  4-parameter coarse-to-fine Lucas-Kanade (yaw, pitch, roll-rate, zoom), numpy only.
  Cowl-masked. Dark/ill-conditioned = null, never 0-fill.

measuredLeanDeg : absolute world-vertical tilt, cowl-masked, dark-gated.
                  Sign: + = right lean (clockwise plate roll).
yawRate         : LK yaw (rad/s). + = right heading change.
targetLeanDeg   : atan(v ω / g) at frozen 127 ms lead, clamp 48°.
deficitLeanDeg  = targetLeanDeg - measuredLeanDeg. null => FAIL_CLOSED.
deficitRollDeg  alias of deficitLeanDeg (camera swing at dial=1).

No loop. No modulo. No stretch. No hold-last. Decoded-frame index.
"""
from __future__ import annotations

import hashlib
import json
import math
import struct
import subprocess
import sys
from pathlib import Path

import numpy as np

SRC = Path("/workspace/attachments/ride.mp4")
WANT_SHA = "4507a5d5f9304b91c149200672c8a468f089a33bb96b10032a52346085483882"
OUT_DIR = Path("/workspace/motion")
PUB_DIR = Path("/workspace/public/motion")

# analysis resolution (3:2, same as 1728x1152)
W, H = 576, 384
HFOV_DEG = 72.0
G = 9.81
V_CRUISE = 24.0
GAIN = 1.0
MAX_LEAN_DEG = 48.0
LEAD_FROZEN_MS = 127.0
LEAD_BAND = (118.0, 136.0)
FPS_NOM = 24.0
DURATION_NOM = 1514 / 24.0  # 63.083333...
WINDOW_MS = 1500.0
HOP_MS = 250.0

# cowl is the lower ~40% + center bulge. LK and tilt use the upper field only.
COWL_Y = 0.56


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def mp4_duration_sec(path: Path) -> float:
    data = path.read_bytes()[: 4_000_000]
    idx = data.find(b"mvhd")
    payload = data[idx + 4 :]
    version = payload[0]
    if version == 1:
        timescale = struct.unpack(">I", payload[20:24])[0]
        duration = struct.unpack(">Q", payload[24:32])[0]
    else:
        timescale = struct.unpack(">I", payload[12:16])[0]
        duration = struct.unpack(">I", payload[16:20])[0]
    return duration / timescale


def decode_gray(path: Path, w: int, h: int) -> np.ndarray:
    cmd = [
        "ffmpeg", "-v", "error", "-i", str(path), "-an",
        "-fps_mode", "passthrough",
        "-vf", f"scale={w}:{h},format=gray",
        "-f", "rawvideo", "pipe:1",
    ]
    raw = subprocess.run(cmd, stdout=subprocess.PIPE, check=True).stdout
    n = len(raw) // (w * h)
    return np.frombuffer(raw[: n * w * h], dtype=np.uint8).reshape(n, h, w)


def decode_rgb(path: Path, w: int, h: int) -> np.ndarray:
    cmd = [
        "ffmpeg", "-v", "error", "-i", str(path), "-an",
        "-fps_mode", "passthrough",
        "-vf", f"scale={w}:{h}",
        "-pix_fmt", "rgb24", "-f", "rawvideo", "pipe:1",
    ]
    raw = subprocess.run(cmd, stdout=subprocess.PIPE, check=True).stdout
    n = len(raw) // (w * h * 3)
    return np.frombuffer(raw[: n * w * h * 3], dtype=np.uint8).reshape(n, h, w, 3)


def gaussian_blur3(img: np.ndarray) -> np.ndarray:
    """Separable [1,2,1]/4 blur, float32."""
    k = np.array([1.0, 2.0, 1.0], dtype=np.float32) / 4.0
    tmp = np.empty_like(img, dtype=np.float32)
    out = np.empty_like(img, dtype=np.float32)
    for r in range(img.shape[0]):
        tmp[r] = np.convolve(img[r].astype(np.float32), k, mode="same")
    for c in range(img.shape[1]):
        out[:, c] = np.convolve(tmp[:, c], k, mode="same")
    return out


def downsample2(img: np.ndarray) -> np.ndarray:
    h, w = img.shape
    h2, w2 = h // 2, w // 2
    a = img[: h2 * 2, : w2 * 2].astype(np.float32)
    return (a[0::2, 0::2] + a[0::2, 1::2] + a[1::2, 0::2] + a[1::2, 1::2]) * 0.25


def bilinear(img: np.ndarray, x: np.ndarray, y: np.ndarray):
    h, w = img.shape
    x0 = np.floor(x).astype(np.int32)
    y0 = np.floor(y).astype(np.int32)
    x1 = x0 + 1
    y1 = y0 + 1
    fx = (x - x0).astype(np.float64)
    fy = (y - y0).astype(np.float64)
    valid = (x0 >= 0) & (x1 < w) & (y0 >= 0) & (y1 < h)
    x0c = np.clip(x0, 0, w - 1)
    x1c = np.clip(x1, 0, w - 1)
    y0c = np.clip(y0, 0, h - 1)
    y1c = np.clip(y1, 0, h - 1)
    Ia = img[y0c, x0c]
    Ib = img[y0c, x1c]
    Ic = img[y1c, x0c]
    Id = img[y1c, x1c]
    val = (
        (1.0 - fx) * (1.0 - fy) * Ia
        + fx * (1.0 - fy) * Ib
        + (1.0 - fx) * fy * Ic
        + fx * fy * Id
    )
    return val, valid


def sobel_xy(img: np.ndarray):
    ix = np.zeros_like(img, dtype=np.float64)
    iy = np.zeros_like(img, dtype=np.float64)
    ix[:, 1:-1] = 0.5 * (img[:, 2:] - img[:, :-2])
    iy[1:-1, :] = 0.5 * (img[2:, :] - img[:-2, :])
    return ix, iy


def cowl_mask(h: int, w: int) -> np.ndarray:
    ys = np.arange(h)[:, None]
    xs = np.arange(w)[None, :]
    m = np.ones((h, w), dtype=bool)
    m &= ys >= int(0.06 * h)
    m &= ys < int(COWL_Y * h)
    m &= xs >= int(0.07 * w)
    m &= xs < int(0.93 * w)
    # drop a few rows at the cowl lip
    m &= ys < int(0.54 * h)
    return m


def lk4(I0: np.ndarray, I1: np.ndarray, mask: np.ndarray, niter: int = 7):
    """4-param LK (tx, ty, theta_ccw_rad, scale). Returns None if unmeasurable."""
    if float(np.percentile(I0[mask], 95)) < 16.0:
        return None
    # pyramid: coarse then fine
    levels = []
    a, b, m = I0, I1, mask
    for _ in range(3):
        levels.append((a, b, m))
        a = downsample2(a)
        b = downsample2(b)
        m = m[0::2, 0::2][: a.shape[0], : a.shape[1]]
    tx = ty = th = 0.0
    sc = 1.0
    last_inliers = 0
    last_res = 1e9
    for li in range(len(levels) - 1, -1, -1):
        if li < len(levels) - 1:
            tx *= 2.0
            ty *= 2.0
        img0, img1, mk = levels[li]
        img0f = img0.astype(np.float64)
        img1f = img1.astype(np.float64)
        h, w = img0f.shape
        ix, iy = sobel_xy(img0f)
        ys, xs = np.where(mk)
        if xs.size < 80:
            return None
        # cap points
        if xs.size > 1800:
            step = int(np.ceil(xs.size / 1800))
            xs = xs[::step]
            ys = ys[::step]
        xs = xs.astype(np.float64)
        ys = ys.astype(np.float64)
        mag = np.hypot(ix[ys.astype(int), xs.astype(int)], iy[ys.astype(int), xs.astype(int)])
        keep = mag >= 4.0
        if int(keep.sum()) < 60:
            return None
        xs, ys = xs[keep], ys[keep]
        cx, cy = (w - 1) * 0.5, (h - 1) * 0.5
        I0p = img0f[ys.astype(int), xs.astype(int)]
        Ixp = ix[ys.astype(int), xs.astype(int)]
        Iyp = iy[ys.astype(int), xs.astype(int)]
        for _it in range(niter):
            u = xs - cx
            v = ys - cy
            ct, st = math.cos(th), math.sin(th)
            xw = cx + sc * (u * ct - v * st) + tx
            yw = cy + sc * (u * st + v * ct) + ty
            I1w, valid = bilinear(img1f, xw, yw)
            ok = valid
            if int(ok.sum()) < 60:
                return None
            r = I0p - I1w
            # Huber weights
            absr = np.abs(r)
            c = np.percentile(absr[ok], 70) if int(ok.sum()) else 8.0
            c = max(4.0, float(c))
            wgt = np.ones_like(r)
            big = absr > c
            wgt[big] = c / np.maximum(absr[big], 1e-6)
            wgt[~ok] = 0.0
            # Jacobian of warp wrt [tx, ty, th, sc]
            # dW/dtx = (1, 0)
            # dW/dty = (0, 1)
            # dW/dth = sc * (-u sin - v cos, u cos - v sin) = (-sc*(u st + v ct), sc*(u ct - v st))
            # dW/dsc = (u ct - v st, u st + v ct)
            jx_tx, jy_tx = 1.0, 0.0
            jx_ty, jy_ty = 0.0, 1.0
            jx_th = -sc * (u * st + v * ct)
            jy_th = sc * (u * ct - v * st)
            jx_sc = u * ct - v * st
            jy_sc = u * st + v * ct
            sd = np.stack(
                [
                    Ixp * jx_tx + Iyp * jy_tx,
                    Ixp * jx_ty + Iyp * jy_ty,
                    Ixp * jx_th + Iyp * jy_th,
                    Ixp * jx_sc + Iyp * jy_sc,
                ],
                axis=1,
            )  # N x 4
            sw = np.sqrt(wgt)
            sdw = sd * sw[:, None]
            rw = r * sw
            H = sdw.T @ sdw
            bvec = sdw.T @ rw
            try:
                dp = np.linalg.solve(H, bvec)
            except np.linalg.LinAlgError:
                return None
            # damping
            tx += float(dp[0])
            ty += float(dp[1])
            th += float(dp[2])
            sc += float(dp[3])
            if sc < 0.85 or sc > 1.18:
                return None
            if abs(th) > 0.25:
                return None
            if abs(float(dp[0])) < 1e-4 and abs(float(dp[1])) < 1e-4 and abs(float(dp[2])) < 1e-6:
                break
        last_inliers = int((wgt > 0.3).sum())
        last_res = float(np.median(np.abs(r[ok]))) if int(ok.sum()) else 1e9
    if last_inliers < 60 or last_res > 28.0:
        return None
    return {
        "tx": float(tx),
        "ty": float(ty),
        "theta": float(th),
        "scale": float(sc),
        "inliers": last_inliers,
        "residual": last_res,
    }


def vertical_tilt_deg(img: np.ndarray, mask: np.ndarray):
    """Clockwise-from-vertical world tilt in degrees. None if unmeasurable.
    Internal math: +angle is CCW from +x; we convert so + = clockwise plate roll.
    """
    if float(np.percentile(img[mask], 95)) < 16.0:
        return None
    ix, iy = sobel_xy(img.astype(np.float64))
    mag = np.hypot(ix, iy)
    ang = np.arctan2(iy, ix)
    near_v = (np.abs(ang) < 0.50) | (np.abs(np.abs(ang) - np.pi) < 0.50)
    wgt = mag * near_v * mask
    if float(wgt.sum()) < 250:
        return None
    a = ang.copy()
    a[a > np.pi / 2] -= np.pi
    a[a < -np.pi / 2] += np.pi
    s = float((np.sin(2 * a) * wgt).sum() / wgt.sum())
    c = float((np.cos(2 * a) * wgt).sum() / wgt.sum())
    # 0.5 atan2(s,c) is the dominant gradient orientation relative to +x.
    # Vertical edges have gradient along +x (ang~0), so this is the tilt of the edge
    # from vertical. Positive = CCW edge tilt = CCW camera roll.
    # We want + = clockwise plate roll (right lean) => negate.
    return math.degrees(0.5 * math.atan2(s, c)) * -1.0


def median_odd(x: np.ndarray, k: int) -> np.ndarray:
    """Smooth finite samples only. NaN stays NaN — never hole-fill."""
    y = x.copy()
    r = k // 2
    for i in range(x.size):
        if not np.isfinite(x[i]):
            continue
        sl = x[max(0, i - r) : min(x.size, i + r + 1)]
        fin = sl[np.isfinite(sl)]
        if fin.size:
            y[i] = np.median(fin)
    return y


def pearson_lag(a, b, lag):
    n = min(a.size, b.size) - lag
    if n < 8:
        return 0.0
    xa = a[:n] - a[:n].mean()
    xb = b[lag : lag + n] - b[lag : lag + n].mean()
    den = float(np.sqrt((xa * xa).sum() * (xb * xb).sum()))
    return 0.0 if den < 1e-12 else float((xa * xb).sum() / den)


def measure_lead(roll, yaw_rate, hz, min_ms=60.0, max_ms=360.0):
    min_lag = max(0, int(round((min_ms / 1000.0) * hz)))
    max_lag = max(min_lag, int(round((max_ms / 1000.0) * hz)))
    best_c, best_l = -2.0, min_lag
    for lag in range(min_lag, max_lag + 1):
        c = pearson_lag(roll, yaw_rate, lag)
        if c > best_c:
            best_c, best_l = c, lag
    return {"leadMs": (best_l / hz) * 1000.0, "corr": best_c}


def r4(x):
    return float(round(float(x), 4))


def phrase_of(w, prev, missing):
    if missing:
        return "fail_closed"
    a = abs(w)
    if prev != 0 and w != 0 and (prev > 0) != (w > 0) and a > 0.08:
        return "transition"
    dabs = a - abs(prev)
    if a < 0.035:
        return "recover" if dabs < -0.015 else "straight"
    if a < 0.10:
        return "shallow"
    if a < 0.20:
        return "medium"
    return "aggressive"


def arr(x):
    out = []
    for v in x:
        if isinstance(v, (float, np.floating)) and not math.isfinite(float(v)):
            out.append(None)
        else:
            out.append(r4(float(v)))
    return out


def main() -> int:
    got = sha256_file(SRC)
    print("SOURCE_SHA256", got, flush=True)
    if got != WANT_SHA:
        print("STOP: hash mismatch want", WANT_SHA)
        return 2
    duration_mvhd = mp4_duration_sec(SRC)
    print("mvhd_duration", duration_mvhd, "bytes", SRC.stat().st_size, flush=True)

    print("decode gray", W, "x", H, flush=True)
    gray_u8 = decode_gray(SRC, W, H)
    n = int(gray_u8.shape[0])
    print("decoded", n, flush=True)
    if n != 1514:
        print("STOP: decoded-frame-count", n, "expected 1514")
        return 3

    # Frozen timeline: decoded index / 24. Duration = 1514/24 = 63.083333s.
    sample_hz = FPS_NOM
    duration = DURATION_NOM
    t = np.arange(n, dtype=np.float64) / sample_hz

    mask = cowl_mask(H, W)
    fpx = (W * 0.5) / math.tan(math.radians(HFOV_DEG) * 0.5)
    fpy = (H * 0.5) / math.tan(math.radians(HFOV_DEG * (H / W)) * 0.5)

    tilt = np.full(n, np.nan)
    yaw_px = np.full(n, np.nan)      # tx pixels (frame i vs i-1)
    pitch_px = np.full(n, np.nan)
    roll_rad = np.full(n, np.nan)    # CCW image rotation this frame
    zoom = np.full(n, np.nan)
    lk_res = np.full(n, np.nan)
    lk_in = np.full(n, np.nan)

    # blur once
    print("blur + tilt", flush=True)
    gray = np.empty((n, H, W), dtype=np.float32)
    for i in range(n):
        gray[i] = gaussian_blur3(gray_u8[i])
        tlt = vertical_tilt_deg(gray[i], mask)
        if tlt is not None:
            tilt[i] = tlt
        if i % 200 == 0:
            print(f"  tilt {i}/{n} = {tilt[i]}", flush=True)

    print("LK 4-param", flush=True)
    for i in range(1, n):
        est = lk4(gray[i - 1], gray[i], mask)
        if est is not None:
            yaw_px[i] = est["tx"]
            pitch_px[i] = est["ty"]
            roll_rad[i] = est["theta"]
            zoom[i] = est["scale"]
            lk_res[i] = est["residual"]
            lk_in[i] = est["inliers"]
        if i % 100 == 0:
            print(
                f"  lk {i}/{n} tx={yaw_px[i]} th={roll_rad[i]} in={lk_in[i]} res={lk_res[i]}",
                flush=True,
            )

    measured = tilt.copy()

    # Optical yaw: camera yaw-right produces scene shift left => tx < 0.
    # yawRate (rad/s, + right) = -tx / fpx * fps
    yaw_rate = np.full(n, np.nan)
    ok = np.isfinite(yaw_px)
    yaw_rate[ok] = -(yaw_px[ok] / fpx) * sample_hz
    yaw_rate = median_odd(yaw_rate, 5)
    yaw_rate[~ok] = np.nan

    pitch_rate = np.full(n, np.nan)
    okp = np.isfinite(pitch_px)
    pitch_rate[okp] = -(pitch_px[okp] / fpy) * sample_hz
    pitch_rate = median_odd(pitch_rate, 5)
    pitch_rate[~okp] = np.nan

    # rollRateDegS: + = right lean rate = clockwise = -theta_ccw * fps in degrees
    roll_rate_deg = np.full(n, np.nan)
    okr = np.isfinite(roll_rad)
    roll_rate_deg[okr] = -np.degrees(roll_rad[okr]) * sample_hz
    roll_rate_deg = median_odd(roll_rate_deg, 5)
    roll_rate_deg[~okr] = np.nan

    yaw_deg = np.degrees(yaw_rate)

    heading = np.full(n, np.nan)
    last_h = 0.0
    have_h = False
    for i in range(n):
        if np.isfinite(yaw_rate[i]):
            if not have_h:
                last_h = 0.0
                have_h = True
                heading[i] = last_h
            else:
                last_h = last_h + yaw_rate[i] / sample_hz
                heading[i] = last_h

    lead_ms = LEAD_FROZEN_MS
    lead_samples = int(round((lead_ms / 1000.0) * sample_hz))  # 3 at 24 Hz
    target = np.full(n, np.nan)
    maxr = math.radians(MAX_LEAN_DEG)
    for i in range(n):
        j = i + lead_samples
        if j >= n:
            omega = 0.0
        elif not np.isfinite(yaw_rate[j]):
            continue
        else:
            omega = float(yaw_rate[j])
        th = math.atan((V_CRUISE * omega) / G) * GAIN
        th = max(-maxr, min(maxr, th))
        target[i] = math.degrees(th)

    deficit = np.full(n, np.nan)
    both = np.isfinite(target) & np.isfinite(measured)
    deficit[both] = target[both] - measured[both]

    phrase = []
    prev = 0.0
    for i in range(n):
        missing = not np.isfinite(yaw_rate[i])
        w = float(yaw_rate[i]) if not missing else 0.0
        phrase.append(phrase_of(w, prev, missing))
        if not missing:
            prev = w

    win = max(8, int(round((WINDOW_MS / 1000.0) * sample_hz)))
    hop = max(1, int(round((HOP_MS / 1000.0) * sample_hz)))
    windows = []
    for i0 in range(0, n - win, hop):
        sl = slice(i0, i0 + win)
        pair = np.isfinite(measured[sl]) & np.isfinite(yaw_deg[sl])
        nfin_m = int(np.isfinite(measured[sl]).sum())
        nfin_y = int(np.isfinite(yaw_deg[sl]).sum())
        if nfin_m < 12 or nfin_y < 12 or int(pair.sum()) < 12:
            windows.append({
                "t0": r4(t[i0]), "t1": r4(t[min(n - 1, i0 + win)]),
                "i0": i0, "i1": i0 + win, "verdict": "FAIL_CLOSED",
                "corr": None, "leadMs": None, "yawRms": None, "rollRms": None,
            })
            continue
        rr = measured[sl][np.isfinite(measured[sl])]
        yy = yaw_deg[sl][np.isfinite(yaw_deg[sl])]
        lead = measure_lead(measured[sl][pair], yaw_deg[sl][pair], sample_hz)
        yaw_rms = float(np.sqrt(np.mean(yy * yy)))
        roll_rms = float(np.sqrt(np.mean(rr * rr)))
        verdict = "HOLD"
        if yaw_rms >= 8.0:
            if roll_rms < 3.0:
                verdict = "FRAUD"
            elif lead["corr"] is not None and lead["corr"] >= 0.55 and 60 <= lead["leadMs"] <= 360:
                verdict = "PASS"
            else:
                verdict = "FRAUD"
        windows.append({
            "t0": r4(t[i0]), "t1": r4(t[min(n - 1, i0 + win)]),
            "i0": i0, "i1": i0 + win,
            "corr": r4(lead["corr"]) if lead["corr"] is not None else None,
            "leadMs": r4(lead["leadMs"]) if lead["leadMs"] is not None else None,
            "yawRms": r4(yaw_rms), "rollRms": r4(roll_rms), "verdict": verdict,
        })
    pass_w = [w for w in windows if w["verdict"] == "PASS"]
    fraud_w = [w for w in windows if w["verdict"] == "FRAUD"]
    plate_lead = float(np.median([w["leadMs"] for w in pass_w if w["leadMs"] is not None])) if pass_w else None
    plate_corr = float(np.median([w["corr"] for w in pass_w if w["corr"] is not None])) if pass_w else None

    # model correlation: targetLean[i] vs yaw[i+lead] (by construction high)
    model_pairs_t = []
    model_pairs_y = []
    for i in range(n - lead_samples):
        if np.isfinite(target[i]) and np.isfinite(yaw_deg[i + lead_samples]):
            model_pairs_t.append(target[i])
            model_pairs_y.append(yaw_deg[i + lead_samples])
    if len(model_pairs_t) >= 12:
        mt = np.asarray(model_pairs_t)
        my = np.asarray(model_pairs_y)
        mt = mt - mt.mean()
        my = my - my.mean()
        den = float(np.sqrt((mt * mt).sum() * (my * my).sum()))
        model_corr = 0.0 if den < 1e-12 else float((mt * my).sum() / den)
    else:
        model_corr = None

    turns = []
    i = 0
    while i < n:
        if not np.isfinite(yaw_deg[i]) or abs(yaw_deg[i]) < 8:
            i += 1
            continue
        j = i
        while j < n and np.isfinite(yaw_deg[j]) and abs(yaw_deg[j]) >= 5:
            j += 1
        if j - i >= 6:
            sl = slice(i, j)
            pair = np.isfinite(measured[sl]) & np.isfinite(yaw_deg[sl])
            rr = measured[sl][np.isfinite(measured[sl])]
            yy = yaw_deg[sl][np.isfinite(yaw_deg[sl])]
            if int(pair.sum()) >= 6:
                lead = measure_lead(measured[sl][pair], yaw_deg[sl][pair], sample_hz)
            else:
                lead = {"leadMs": None, "corr": None}
            yaw_rms = float(np.sqrt(np.mean(yy * yy))) if yy.size else 0.0
            roll_rms = float(np.sqrt(np.mean(rr * rr))) if rr.size else 0.0
            dmax = float(np.nanmax(np.abs(deficit[sl]))) if np.isfinite(deficit[sl]).any() else None
            if int(pair.sum()) < 6:
                verdict = "FAIL_CLOSED"
            elif roll_rms < 3.0 and yaw_rms >= 8:
                verdict = "FRAUD"
            elif lead["corr"] is not None and lead["corr"] >= 0.55 and lead["leadMs"] is not None and 60 <= lead["leadMs"] <= 360:
                verdict = "PASS"
            else:
                verdict = "FRAUD"
            turns.append({
                "decodedFrameStart": int(i),
                "decodedFrameEnd": int(j - 1),
                "videoTimestampStart": r4(t[i]),
                "videoTimestampEnd": r4(t[j - 1]),
                "yawRmsDegS": r4(yaw_rms),
                "headingChangeDeg": r4(math.degrees(float(np.nansum(yaw_rate[sl]) / sample_hz))),
                "measuredLeanRmsDeg": r4(roll_rms),
                "maxAbsDeficitDeg": r4(dmax) if dmax is not None else None,
                "leadMs": r4(lead["leadMs"]) if lead["leadMs"] is not None else None,
                "corr": r4(lead["corr"]) if lead["corr"] is not None else None,
                "verdict": verdict,
            })
        i = max(j, i + 1)

    print("--- sanity ---")
    for tm in [0, 0.5, 1.75, 8.76, 11.67, 18.75, 31.54, 36.80, 50.0, 62.2, 63.0]:
        i = min(n - 1, max(0, int(round(tm * sample_hz))))
        print(
            f"t={tm:6.2f} i={i:4d} yaw={yaw_deg[i]:+7.2f} "
            f"lean={measured[i]:+6.2f} tgt={target[i]:+6.2f} def={deficit[i]:+6.2f} "
            f"tx={yaw_px[i]:+6.2f} phr={phrase[i]}",
            flush=True,
        )
    print("PASS windows", len(pass_w), "FRAUD", len(fraud_w), "turns", len(turns), flush=True)
    print(
        "finite measured", int(np.isfinite(measured).sum()),
        "finite yaw", int(np.isfinite(yaw_rate).sum()),
        "finite deficit", int(np.isfinite(deficit).sum()),
        flush=True,
    )

    finite_def = deficit[np.isfinite(deficit)]
    max_def = float(np.max(np.abs(finite_def))) if finite_def.size else None
    meas_rms = float(np.sqrt(np.mean(measured[np.isfinite(measured)] ** 2))) if np.isfinite(measured).any() else None
    yaw_rms = float(np.sqrt(np.mean(yaw_deg[np.isfinite(yaw_deg)] ** 2))) if np.isfinite(yaw_deg).any() else None

    # no-repeat proof
    ts = [r4(x) for x in t]
    no_repeat = len(ts) == len(set(ts)) and all(ts[i] < ts[i + 1] for i in range(len(ts) - 1))

    payload = {
        "status": "OK",
        "version": "v9-full",
        "frozen": True,
        "sourceVideoSha256": got,
        "sourcePresent": True,
        "headsetSourceValidated": False,
        "source": {
            "path": "attachments/ride.mp4",
            "bytes": SRC.stat().st_size,
            "durationSec": r4(duration),
            "mvhdDurationSec": r4(duration_mvhd),
            "decodedFrameCount": n,
            "width": 1728,
            "height": 1152,
            "containerFps": 24,
            "identity": "ride-master-63s-cowl-pov",
            "hfovDeg": HFOV_DEG,
            "analysisResolution": [W, H],
        },
        "ride4k": {
            "present": False,
            "reportedSha256": "7e51e4adc7e82ff82396ec22f2867b05b66f8259388a52530f6e5cbfe87b4059",
            "reportedSize": [3240, 2160],
            "reportedFrames": 1514,
            "reportedFps": 24,
            "reportedDurationSec": 63.083333,
            "spatialScaleVsRideMp4": 3240 / 1728,
            "aspectRide": "1728x1152 = 3:2",
            "aspect4k": "3240x2160 = 3:2",
            "uniformScale": True,
            "cropSuspected": False,
            "angularMotionInvariantIfSameCrop": True,
            "note": "ride-4k.mp4 bytes are NOT in this workspace. Uniform 1.875x on the same 3:2 means LK yaw/roll ANGLES are invariant to the scale. Pixel translations would scale 1.875x and cancel against focal length. Headset-source validation is NOT claimed. Representative turns must be re-measured on ride-4k.mp4 before headset integration.",
        },
        "frameCount": n,
        "sampleCount": n,
        "sampleRate": r4(sample_hz),
        "timestampScheme": "decoded-frame-index. t[i] = i / 24. Frame 0 at 0.000s. Frame 1513 at 62.208333s. Source duration = 1514/24 = 63.083333s (last frame occupies [62.208333, 63.083333)). NEVER duration*nominal-fps resample. NEVER modulo.",
        "firstSampleTimestamp": 0.0,
        "lastSampleTimestamp": r4(float(t[-1])),
        "lastFrameEndTimestamp": r4(duration),
        "leadMs": r4(lead_ms),
        "leadBandMs": [LEAD_BAND[0], LEAD_BAND[1]],
        "correlation": r4(plate_corr) if plate_corr is not None else None,
        "modelCorrelation": r4(model_corr) if model_corr is not None else None,
        "leadSource": "frozen-127ms (Claude measured band 118–136). Plate horizon is near-level; per-window lean-vs-yaw lead is not a stable plate measurement. Consumer bakes target at 127 ms.",
        "plateMeasuredLeadMs": r4(plate_lead) if plate_lead is not None else None,
        "G": G,
        "vCruiseMs": V_CRUISE,
        "leanGain": GAIN,
        "maxLeanDeg": MAX_LEAN_DEG,
        "deficit": "deficitLeanDeg[i] = deficitRollDeg[i] = targetLeanDeg[i] - measuredLeanDeg[i]. null => FAIL_CLOSED, never 0-fill.",
        "cameraRoll": "cameraRollDeg[i] = dial * deficitRollDeg[i]. dial 0 = plate as-is (level-horizon defect). dial 1 = full physically-derived target. Plant vehicle forces roll = 0.",
        "endOfTrack": {
            "wrap": False,
            "loop": False,
            "holdLastSampleAfterEnd": False,
            "outOfRange": "FAIL_CLOSED",
            "tailLookahead": "target uses yawRate[i+leadSamples]; past last decoded frame upcoming yaw = 0 (upright), not hold-last",
        },
        "alignment": {
            "beginsAtVideoFrame0": True,
            "endsAtFinalVideoFrame": True,
            "timelineRepetition": False,
            "loop": False,
            "holdLastSampleAfterEnd": False,
            "firstDecodedFrame": 0,
            "lastDecodedFrame": n - 1,
            "monotonicTimestamps": no_repeat,
            "uniqueTimestamps": no_repeat,
        },
        "measurement": {
            "instrument": "coarse-to-fine 4-param Lucas-Kanade (tx, ty, theta, scale) on cowl-masked upper field, 3-level pyramid, Huber weights. numpy only.",
            "measuredLean": "per-frame vertical-line tilt of world verticals, cowl-masked, dark-gated. Sign: + = right lean (clockwise plate roll). Absolute, no integration drift, no origin 0-fill.",
            "yawRate": "LK tx converted through assumed HFOV 72 deg: yawRate = -tx/fpx * 24. + = right heading change. median-5 on finite samples only (holes stay null).",
            "rollRate": "LK theta: rollRateDegS = -deg(theta)*24. + = right lean rate. Diagnostic; not integrated (would drift). Absolute lean is measuredLeanDeg.",
            "targetLean": "atan(v*omega/g) with v=24 m/s, lead 127 ms (3 samples at 24 Hz), clamp 48 deg. Lead sample missing => target null (FAIL_CLOSED). Past last frame upcoming yaw = 0.",
            "cowlMask": "y in [0.06, 0.54] H, x in [0.07, 0.93] W. Lower ~46% (physical cowl) excluded.",
            "measuredLeanRmsDeg": r4(meas_rms) if meas_rms is not None else None,
            "yawRmsDegS": r4(yaw_rms) if yaw_rms is not None else None,
            "leadSamples": lead_samples,
            "fpx": r4(fpx),
            "lkFinite": int(np.isfinite(yaw_px).sum()),
            "tiltFinite": int(np.isfinite(measured).sum()),
        },
        "windows": windows,
        "perTurnLeadMs": turns,
        "maxDeficitDeg": r4(max_def) if max_def is not None else None,
        "decodedFrame": list(range(n)),
        "videoTimestamp": arr(t),
        "heading": arr(heading),
        "yawRate": arr(yaw_rate),
        "yawRateDegS": arr(yaw_deg),
        "pitchRate": arr(pitch_rate),
        "rollRateDegS": arr(roll_rate_deg),
        "lkTxPx": arr(yaw_px),
        "lkZoom": arr(zoom),
        "measuredLeanDeg": arr(measured),
        "targetLeanDeg": arr(target),
        "deficitLeanDeg": arr(deficit),
        "deficitRollDeg": arr(deficit),
        "cameraRollDial0": [0.0 if np.isfinite(deficit[i]) else None for i in range(n)],
        "cameraRollDial1": arr(deficit),
        "phrase": phrase,
    }

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    PUB_DIR.mkdir(parents=True, exist_ok=True)
    text = json.dumps(payload, separators=(",", ":"))
    out_json = OUT_DIR / "v9-full.json"
    out_json.write_text(text)
    (PUB_DIR / "v9-full.json").write_text(text)
    payload_sha = hashlib.sha256(text.encode()).hexdigest()

    js = (
        "/* LEAN GATE v9-full — synchronous inline payload. NO fetch. Decoded-frame index. NO wrap. */\n"
        "(function(root){\n"
        "var P=" + text + ";\n"
        "P.frame=function(i){"
        "if(i==null||i<0||i>=P.sampleCount)return{status:'FAIL_CLOSED',i:i,reason:'out of range — no hold-last, no wrap'};"
        "var m=P.measuredLeanDeg[i],t=P.targetLeanDeg[i];"
        "if(m==null||t==null)return{status:'FAIL_CLOSED',i:i,t:P.videoTimestamp[i],measuredLeanDeg:m,targetLeanDeg:t,deficitLeanDeg:null,deficitRollDeg:null};"
        "var d=t-m;"
        "return{status:'OK',i:i,t:P.videoTimestamp[i],heading:P.heading[i],yawRate:P.yawRate[i],"
        "measuredLeanDeg:m,targetLeanDeg:t,deficitLeanDeg:d,deficitRollDeg:d,cameraRollDial0:0,cameraRollDial1:d,phrase:P.phrase[i]};"
        "};\n"
        "root.MOTION_PAYLOAD=P;\n"
        "root.__GROK_MOTION_PAYLOAD=P;\n"
        "root.MOTION=root.MOTION||{};\n"
        "root.MOTION.payload=P;\n"
        "root.MOTION.leadMs=P.leadMs;\n"
        "root.MOTION.leadBandMs=P.leadBandMs;\n"
        "})(typeof window!=='undefined'?window:globalThis);\n"
    )
    (OUT_DIR / "v9-inline.js").write_text(js)
    (PUB_DIR / "v9-inline.js").write_text(js)
    (PUB_DIR / "payload.js").write_text(js)

    def frame_at(k):
        return {
            "decodedFrame": k,
            "videoTimestamp": payload["videoTimestamp"][k],
            "heading": payload["heading"][k],
            "yawRate": payload["yawRate"][k],
            "yawRateDegS": payload["yawRateDegS"][k],
            "measuredLeanDeg": payload["measuredLeanDeg"][k],
            "targetLeanDeg": payload["targetLeanDeg"][k],
            "deficitLeanDeg": payload["deficitLeanDeg"][k],
            "deficitRollDeg": payload["deficitRollDeg"][k],
            "phrase": payload["phrase"][k],
        }

    mid = n // 2
    proof = {
        "sourceVideoSha256": got,
        "payloadSha256": payload_sha,
        "payloadBytes": len(text.encode()),
        "inlineBytes": len(js.encode()),
        "sourceDurationSec": r4(duration),
        "sourceDecodedFrameCount": n,
        "motionSampleCount": n,
        "motionSampleRate": r4(sample_hz),
        "firstSampleTimestamp": 0.0,
        "lastSampleTimestamp": r4(float(t[-1])),
        "lastFrameEndTimestamp": r4(duration),
        "maxDeficitDeg": payload["maxDeficitDeg"],
        "leadMs": lead_ms,
        "leadBandMs": [LEAD_BAND[0], LEAD_BAND[1]],
        "correlation": payload["correlation"],
        "modelCorrelation": payload["modelCorrelation"],
        "PASS_windows": len(pass_w),
        "FRAUD_windows": len(fraud_w),
        "perTurnLeadMs": turns,
        "alignment": payload["alignment"],
        "first3": [frame_at(0), frame_at(1), frame_at(2)],
        "middle3": [frame_at(mid - 1), frame_at(mid), frame_at(mid + 1)],
        "last3": [frame_at(n - 3), frame_at(n - 2), frame_at(n - 1)],
        "finiteMeasured": int(np.isfinite(measured).sum()),
        "finiteYaw": int(np.isfinite(yaw_rate).sum()),
        "finiteDeficit": int(np.isfinite(deficit).sum()),
        "measuredLeanRmsDeg": payload["measurement"]["measuredLeanRmsDeg"],
        "yawRmsDegS": payload["measurement"]["yawRmsDegS"],
        "measuredNotAllZero": bool(np.isfinite(measured).any() and np.nanmax(np.abs(measured)) > 1e-6),
        "zeroFill": False,
        "loop": False,
        "holdLast": False,
        "noRepeat": no_repeat,
        "headsetSourceValidated": False,
    }
    (OUT_DIR / "v9-full-proof.json").write_text(json.dumps(proof, indent=2))

    print("WROTE v9-full.json", payload_sha, "bytes", proof["payloadBytes"], flush=True)
    print(json.dumps({k: proof[k] for k in (
        "sourceDecodedFrameCount", "motionSampleCount", "motionSampleRate",
        "firstSampleTimestamp", "lastSampleTimestamp", "lastFrameEndTimestamp",
        "maxDeficitDeg", "leadMs", "PASS_windows", "FRAUD_windows",
        "finiteMeasured", "finiteYaw", "finiteDeficit",
        "measuredLeanRmsDeg", "yawRmsDegS", "modelCorrelation",
        "measuredNotAllZero", "zeroFill", "loop", "holdLast", "noRepeat",
        "first3", "middle3", "last3",
    )}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
