#!/usr/bin/env python3
"""4K vs lo-res window comparison. Does not rewrite the motion track or consumer."""
from __future__ import annotations

import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/workspace/scripts")
from measure_lk_v9 import (  # noqa: E402
    COWL_Y,
    G,
    H,
    HFOV_DEG,
    MAX_LEAN_DEG,
    V_CRUISE,
    W,
    cowl_mask,
    decode_gray,
    gaussian_blur3,
    lk4,
    median_odd,
    vertical_tilt_deg,
)

WANT_4K = "7e51e4adc7e82ff82396ec22f2867b05b66f8259388a52530f6e5cbfe87b4059"
SRC_4K = Path("/workspace/attachments/ride-4k.mp4")
SRC_LO = Path("/workspace/attachments/ride.mp4")
PAYLOAD = Path("/workspace/motion/v9-full.json")
OUT = Path("/workspace/motion/4K-WINDOW-COMPARISON.json")

RANGES = [
    ("boundaries_start", range(0, 6)),
    ("window_227_330", range(227, 331)),
    ("null_864_866", range(864, 867)),
    ("window_867_1063", range(867, 1064)),
    ("null_1152_1154", range(1152, 1155)),
    ("boundaries_end", range(1497, 1514)),
]
EXPLICIT = (261, 899, 1027)
FPS = 24.0


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def target_same_frame(yaw_rate):
    if yaw_rate is None or not math.isfinite(yaw_rate):
        return None
    t = math.degrees(math.atan((V_CRUISE * yaw_rate) / G))
    if t > MAX_LEAN_DEG:
        t = MAX_LEAN_DEG
    if t < -MAX_LEAN_DEG:
        t = -MAX_LEAN_DEG
    return t


def stats(err):
    err = np.asarray(err, dtype=np.float64)
    err = err[np.isfinite(err)]
    if err.size == 0:
        return {"n": 0}
    a = np.abs(err)
    return {
        "n": int(a.size),
        "mean_abs": float(np.mean(a)),
        "median_abs": float(np.median(a)),
        "p95_abs": float(np.percentile(a, 95)),
        "max_abs": float(np.max(a)),
        "mean": float(np.mean(err)),
        "std": float(np.std(err)),
    }


def main() -> int:
    got = sha256_file(SRC_4K)
    print("4K_SHA", got, flush=True)
    if got != WANT_4K:
        print("STOP hash mismatch")
        return 2
    print("4K_BYTES", SRC_4K.stat().st_size, flush=True)

    print("decode 4K ->", W, H, flush=True)
    g4 = decode_gray(SRC_4K, W, H)
    print("decode lo ->", W, H, flush=True)
    gL = decode_gray(SRC_LO, W, H)
    print("n4", g4.shape, "nL", gL.shape, flush=True)
    if g4.shape[0] != 1514 or gL.shape[0] != 1514:
        print("STOP frame count", g4.shape[0], gL.shape[0])
        return 3

    need = set()
    for _, rr in RANGES:
        need.update(rr)
    need.update(EXPLICIT)
    # LK / median context
    ctx = set()
    for i in list(need):
        for d in range(-2, 3):
            j = i + d
            if 0 <= j < 1514:
                ctx.add(j)
    ctx.add(0)

    mask = cowl_mask(H, W)
    fpx = (W * 0.5) / math.tan(math.radians(HFOV_DEG) * 0.5)

    blur4 = {}
    blurL = {}
    print("blur needed", len(ctx), flush=True)
    for i in sorted(ctx):
        blur4[i] = gaussian_blur3(g4[i])
        blurL[i] = gaussian_blur3(gL[i])

    # pixel correspondence on analysis grid (uniform scale test)
    pix = []
    shift_votes = []
    for i in sorted(need):
        a = g4[i].astype(np.float32)
        b = gL[i].astype(np.float32)
        d = a - b
        rmse = float(np.sqrt(np.mean(d * d)))
        aa = a - a.mean()
        bb = b - b.mean()
        den = float(np.sqrt((aa * aa).sum() * (bb * bb).sum()))
        ncc = float((aa * bb).sum() / den) if den > 1e-6 else 0.0
        # integer shift search ±4 on a 96x64 downsample
        sa = a[::6, ::6]
        sb = b[::6, ::6]
        best = (-1.0, 0, 0)
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                yas = slice(max(0, dy), sa.shape[0] + min(0, dy))
                xas = slice(max(0, dx), sa.shape[1] + min(0, dx))
                ybs = slice(max(0, -dy), sb.shape[0] + min(0, -dy))
                xbs = slice(max(0, -dx), sb.shape[1] + min(0, -dx))
                pa = sa[yas, xas]
                pb = sb[ybs, xbs]
                if pa.size < 50:
                    continue
                pa = pa - pa.mean()
                pb = pb - pb.mean()
                dd = float(np.sqrt((pa * pa).sum() * (pb * pb).sum()))
                if dd < 1e-6:
                    continue
                sc = float((pa * pb).sum() / dd)
                if sc > best[0]:
                    best = (sc, dx, dy)
        pix.append({"i": i, "rmse": rmse, "ncc": ncc, "bestShift": [best[1], best[2]], "bestNcc": best[0]})
        shift_votes.append((best[1], best[2]))

    # 4K measurement
    tilt = np.full(1514, np.nan)
    yaw_px = np.full(1514, np.nan)
    print("tilt+LK windows", flush=True)
    for i in sorted(ctx):
        tlt = vertical_tilt_deg(blur4[i], mask)
        if tlt is not None:
            tilt[i] = tlt
        if i == 0:
            continue
        if (i - 1) not in blur4:
            continue
        est = lk4(blur4[i - 1], blur4[i], mask)
        if est is not None:
            yaw_px[i] = est["tx"]
        if i in EXPLICIT or i % 50 == 0:
            print(f"  i={i} tilt={tilt[i]} tx={yaw_px[i]}", flush=True)

    yaw_rate = np.full(1514, np.nan)
    ok = np.isfinite(yaw_px)
    yaw_rate[ok] = -(yaw_px[ok] / fpx) * FPS
    yaw_rate = median_odd(yaw_rate, 5)
    yaw_rate[~ok] = np.nan

    payload = json.loads(PAYLOAD.read_text())
    lo_yaw = payload["yawRate"]
    lo_meas = payload["measuredLeanDeg"]
    lo_tgt = payload["targetLeanDeg"]
    lo_def = payload["deficitLeanDeg"]
    lo_valid = payload["correctionValid"]

    rows = []
    ey = []
    em = []
    ed = []
    et = []
    null_agree = 0
    null_disagree = 0
    both_finite = 0
    for i in sorted(need):
        y4 = yaw_rate[i] if math.isfinite(yaw_rate[i]) else None
        m4 = tilt[i] if math.isfinite(tilt[i]) else None
        t4 = target_same_frame(y4)
        d4 = None if (t4 is None or m4 is None) else (t4 - m4)
        yl, ml, tl, dl = lo_yaw[i], lo_meas[i], lo_tgt[i], lo_def[i]
        v4 = d4 is not None and y4 is not None and m4 is not None
        vl = bool(lo_valid[i]) if lo_valid[i] is not None else (dl is not None)
        if (y4 is None) == (yl is None):
            pass
        if (m4 is None) and (ml is None):
            null_agree += 1
        elif (m4 is None) != (ml is None):
            null_disagree += 1
        if y4 is not None and yl is not None:
            ey.append(y4 - yl)
            both_finite += 1
        if m4 is not None and ml is not None:
            em.append(m4 - ml)
        if t4 is not None and tl is not None:
            et.append(t4 - tl)
        if d4 is not None and dl is not None:
            ed.append(d4 - dl)
        rows.append(
            {
                "i": i,
                "yaw4": None if y4 is None else round(y4, 6),
                "yawLo": yl,
                "meas4": None if m4 is None else round(m4, 6),
                "measLo": ml,
                "tgt4": None if t4 is None else round(t4, 6),
                "tgtLo": tl,
                "def4": None if d4 is None else round(d4, 6),
                "defLo": dl,
                "valid4": v4,
                "validLo": vl,
            }
        )

    explicit_rows = [r for r in rows if r["i"] in EXPLICIT]

    # max-deficit among measured 4K frames in the two big windows
    def max_abs_def(idxs):
        best = None
        for r in rows:
            if r["i"] in idxs and r["def4"] is not None:
                a = abs(r["def4"])
                if best is None or a > best[0]:
                    best = (a, r["i"], r["def4"], r["defLo"])
        return best

    w1 = set(range(227, 331))
    w2 = set(range(867, 1064))

    ncc = [p["ncc"] for p in pix]
    rmse = [p["rmse"] for p in pix]
    from collections import Counter

    shift_mode = Counter(shift_votes).most_common(1)[0]

    report = {
        "status": "NOT_WEAR_READY",
        "fourKValidated": False,
        "source4k": {
            "sha256": got,
            "bytes": SRC_4K.stat().st_size,
            "decodedFrames": int(g4.shape[0]),
            "analysisResolution": [W, H],
            "native": [3240, 2160],
            "fps": 24,
            "durationSec": 1514 / 24.0,
        },
        "method": {
            "sameAsLoRes": "scale to 576x384, cowl mask y 0.06-0.54 x 0.07-0.93, 4-param LK, vertical tilt, HFOV 72, same-frame atan target",
            "median5": "applied on 1514-length array with only window samples finite (edge median may differ ±2 frames)",
            "consumer": "R6 not modified",
        },
        "pixelCorrespondence": {
            "n": len(pix),
            "ncc_mean": float(np.mean(ncc)),
            "ncc_min": float(np.min(ncc)),
            "rmse_mean": float(np.mean(rmse)),
            "rmse_max": float(np.max(rmse)),
            "dominantIntegerShift": {"dx": shift_mode[0][0], "dy": shift_mode[0][1], "count": shift_mode[1]},
            "scale4kOverLo": 3240 / 1728,
            "aspectBoth": "3:2",
        },
        "error": {
            "yawRate": stats(ey),
            "measuredLeanDeg": stats(em),
            "targetLeanDeg": stats(et),
            "deficitLeanDeg": stats(ed),
            "null_both_missing_measuredLean": null_agree,
            "null_disagree_measuredLean": null_disagree,
        },
        "explicit": explicit_rows,
        "maxAbsDeficit4k_227_330": max_abs_def(w1),
        "maxAbsDeficit4k_867_1063": max_abs_def(w2),
        "loResNominated": {
            "261": {"defLo": lo_def[261], "def4": next(r["def4"] for r in explicit_rows if r["i"] == 261)},
            "899": {"defLo": lo_def[899], "def4": next(r["def4"] for r in explicit_rows if r["i"] == 899)},
            "1027": {"defLo": lo_def[1027], "def4": next(r["def4"] for r in explicit_rows if r["i"] == 1027)},
        },
        "rows": rows,
    }
    OUT.write_text(json.dumps(report, indent=2))
    print(json.dumps({k: report[k] for k in report if k != "rows"}, indent=2))
    print("WROTE", OUT)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
